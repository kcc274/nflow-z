These are the accompanying codes of the paper ....

We provide both cINN and cNSF implementations. The codes for cINN is in cinn.tar, while cNSF is provided in run_cnsf.py.

Have fun!

