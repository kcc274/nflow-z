#!/usr/bin/env python
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import argparse
import pyro
import pyro.distributions as dist
import pyro.distributions.transforms as T
import os
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
import pylab as pl
from sklearn.utils import shuffle
from torch.utils.data import DataLoader, TensorDataset
from time import time


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)
#device = torch.device("cpu")
                                                          
#scaling_factor = 0.5   # scale the data to limit the range of data, to avoid cutoff in the data 
split_fraction = [ 0.8, 0.1, 0.1]  # training, validation, and testing fraction in the full dataset
                                            
patience_counter = 0
patience_limit = 40
                                         
num_layers = 3

N_epochs = 400
batch_size = 256

steps = 40000
#steps = 50
Nsamples = 20000                                                          
lr = 1e-3
                                        
change1 = 150
change2 = 250

#save model 
parser = argparse.ArgumentParser()
parser.add_argument("--output", type=str, default="DES/zp_zs.pt")
args = parser.parse_args()
output_model = args.output
    
file = 2123
input_file = f"DES/ZMAG_shape_impute/LS_DR9_withshape_flux_color_error_{file}.txt"

def plot_loss_train_eval(nll_train, nll_valid):
    plt.figure()
    plt.plot(nll_train, label="train")
    plt.plot(nll_valid, label="valid")
    plt.xlabel("Step / 100")
    plt.ylabel("Loss function")
    plt.legend()
    #plt.ylim(-5, 1)
    plt.savefig(f"lossfunction.png", format="png")
    
def get_full_dataset():
    #Z_SPEC GMAG RMAG ZMAG W1MAG W2MAG FLUX_IVAR_G FLUX_IVAR_R FLUX_IVAR_Z FLUX_IVAR_W1 FLUX_IVAR_W2 shape_r shape_p axis_ratio FLUX_G FLUX_R FLUX_Z FLUX_W1 FLUX_W2 COLOR_GR COLOR_RZ COLOR_ZW1 COLOR_W1W2 FLUX_ERR_G FLUX_ERR_R FLUX_ERR_Z FLUX_ERR_W1 FLUX_ERR_W2
    condition_data = np.array(np.loadtxt(input_file, dtype=object, usecols=(14,15,16,17,18,19,20,21,22,23,24,25,26,27), skiprows=1), dtype=np.float64)
    x_data = np.array(np.loadtxt(input_file, dtype=object, usecols=(0), skiprows=1), dtype=np.float64)

    print(condition_data[0])
    print(x_data[0])
    return condition_data, x_data

def train_validate_test_split( condition_data, x_data, itype ):
    split_range =  [ int( np.around( len(condition_data) * np.sum( np.array(split_fraction)[:i] ) ) ) for i
                     in range(len( split_fraction) + 1 ) ]         
    
    data_range = range(split_range[itype],split_range[itype+1])

    x1 = condition_data[data_range]
    x2 = x_data[data_range]

    #x1 = torch.tensor(condition_data[ data_range ], dtype=torch.float32)
    #x2 = torch.tensor(x_data[ data_range ], dtype=torch.float32)[:,None] 
    return x1, x2


def get_mean_min_loglikelihood( dist_x2_given_x1, x1, x2 ):

    #ln_p_x2_given_x1 = dist_x2_given_x1.condition(x1.detach()).log_prob(x2.detach())
    ln_p_x2_given_x1 = dist_x2_given_x1.condition(x1.detach().to(device)).log_prob(x2.detach().to(device))

    loss = -ln_p_x2_given_x1.mean()
    return loss

def model_training( x1_train, x2_train, x1_validate, x2_validate ):
    #dist_base = dist.Normal(torch.zeros(1), torch.ones(1))
    dist_base = dist.Normal(torch.zeros(1).to(device), torch.ones(1).to(device))
    Nconditions = len( x1_train[0,:] )

    # set the neural spline transform parameters
    x2_transform = torch.nn.ModuleList([
        T.conditional_spline(
            1,
            context_dim=Nconditions,
            hidden_dims=[32, 32, 32],
            bound=6.0
        ) for i in range(num_layers)
    ]).to(device)

    dist_x2_given_x1 = dist.ConditionalTransformedDistribution(dist_base, list(x2_transform))
    
    #modules = torch.nn.ModuleList([x2_transform])
    modules = x2_transform
    optimizer = torch.optim.Adam(modules.parameters(), lr=lr, weight_decay=1e-4)

    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer,milestones=[change1, change2], gamma=0.1)

    nll_mean = []
    train_loader = DataLoader(TensorDataset(x1_train, x2_train), batch_size=batch_size, shuffle=True)

    nll_train = []
    nll_valid = []
    best_val_loss = float('inf')
    patience_counter = 0
    t_start = time()

    for epoch in range(N_epochs):
        loss_train = []
        loss_valid = []
        for i, (x1_batch, x2_batch) in enumerate(train_loader):
            x1_batch, x2_batch = x1_batch.to(device), x2_batch.to(device)
            optimizer.zero_grad()
            loss = get_mean_min_loglikelihood(dist_x2_given_x1, x1_batch, x2_batch)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(modules.parameters(), max_norm=10.0)
            optimizer.step()
            dist_x2_given_x1.clear_cache()
            loss_train.append(loss.item())

            val_loss = get_mean_min_loglikelihood( dist_x2_given_x1, x1_validate, x2_validate )
            loss_valid.append(val_loss.item())

            if not i % 100:
                with torch.no_grad():
                    #loss_validate = get_mean_min_loglikelihood( dist_x2_given_x1, x1_validate, x2_validate )
                    #val_loss = loss_validate.item()
                    print('%.3i \t%.5i/%.5i \t%.2f \t%.6f\t%.6f\t%.2e' % (
                        epoch, i, len(train_loader),
                        (time() - t_start)/60.,
                        np.mean(loss_train),
                        np.mean(loss_valid),
                        optimizer.param_groups[0]['lr']), flush=True)

        scheduler.step()

        #print(f"Epoch {epoch:03d}  Train Loss: {np.mean(loss_train):.6f}  Valid Loss: {val_loss:.6f}")
        nll_train.append(np.mean(loss_train))
        nll_valid.append(np.mean(loss_valid))

        if np.mean(loss_valid) < best_val_loss :
            best_val_loss  = np.mean(loss_valid)
            patience_counter = 0
            torch.save(modules.state_dict(), output_model)
        else:
            patience_counter += 1

        if patience_counter >= patience_limit:
            print(f'\nEarly stopping at epoch {epoch}.\nBest validation loss: {best_val_loss:.6f}')
            break

    plot_loss_train_eval(nll_train, nll_valid)

    modules.load_state_dict(torch.load(output_model, map_location=device))
    dist_x2_given_x1 = dist.ConditionalTransformedDistribution(dist_base, list(modules))

    return dist_x2_given_x1
    
def get_outlier_frac(zp, zs,zp_name):
    f = np.abs(zp - zs) / (1 + zs)
    eta = len(np.where(f > 0.1)[0]) / len(f)
    print(f'Outlier fraction, {zp_name:s}: {eta:.4f}')
    return eta

def get_sigma(zp, zs, zp_name):
    dz = zp - zs
    med_dz = np.median(dz)
    sigma_NMAD = 1.48 * np.median(np.abs(dz - med_dz) / (1 + zs))
    print(f'sigma_NMAD, {zp_name:s}: {sigma_NMAD:.4f}')
    return sigma_NMAD

def get_bias(zp, zs, zp_name):
    dz = zp - zs
    bias = np.median(dz)
    print(f'bias, {zp_name:s}: {bias:.4f}')
    return bias  

def get_pit(x2_flow, zs):
    pit = np.zeros(len(zs))
    for i in range(len(zs)):
        pit[i] = np.mean(x2_flow[i] <= zs[i]) 
    return pit

def plot_pdf_for_one_source(x2_flow, zs, z_median, z_spec_range=(0, 2), label=None):
    
    idx_range = np.where((zs >= z_spec_range[0]) & (zs < z_spec_range[1]))[0]
    i = idx_range[0]

    samples = x2_flow[i, :]
    z_spec = zs[i]
    z_pred = z_median[i]

    plt.figure(figsize=(8, 5))
    sns.histplot(samples, bins=50, stat='density', kde=True, color='skyblue', edgecolor='skyblue',alpha=0.5, label='PDF')

    plt.axvline(z_spec, color='red', linestyle='--', label=f'z_spec = {z_spec:.2f}')
    plt.axvline(z_pred, color='orange', linestyle='--', label=f'z_pred = {z_pred:.2f}')
    plt.xlabel('z',fontsize=22)
    plt.ylabel('Density(cNSF)',fontsize=22)
    plt.tick_params(axis='both', labelsize=16)
    plt.legend(fontsize=18)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(f'pdf_zrange_{label}.png')

def test_sample_dist( x1_test, x2_test, zs, mean, std):
    x2_flow = np.zeros([ len(x2_test), Nsamples ])
    for isample in range(Nsamples):
        #x2_flow[:,isample] = dist_x2_given_x1.condition(x1_test).sample(torch.Size( [len(x2_test)] )).squeeze().detach().numpy()
        x2_flow[:, isample] = dist_x2_given_x1.condition(x1_test.to(device)).sample(torch.Size([len(x2_test)])).squeeze().detach().cpu().numpy()

    #x2_flow = x2_flow / scaling_factor    
    x2_flow = x2_flow*std + mean 

    z_maxp = np.zeros( [ len(x2_test[:,0]) ] )
    for i in range(len(x2_test)):    
        hist, bin_edges =  np.histogram( x2_flow[i,:], bins=100000, range=(0,10) ) 
        j = np.argmax(hist)
        z_maxp[i] = ( bin_edges[j+1] + bin_edges[j] ) / 2.
    
    z_median = np.median(x2_flow,axis=1)
    z_mean = np.mean(x2_flow,axis=1)

    err_std = np.std( x2_flow, axis=1 )
    err_68halfpc= ( np.percentile( x2_flow, 84, axis=1 ) - np.percentile( x2_flow, 16, axis=1 ) ) / 2 

    pit = get_pit(x2_flow, zs)
  
    #plot_pdf_for_one_source(x2_flow, zs, i=10)

    return z_maxp, z_median, z_mean, err_std, err_68halfpc, pit   

def make_scatter_plot( zp_estimate_list, zp_name_list ):
    fig, ax = pl.subplots()
    for i in range(len(zp_estimate_list)):
        zp, zp_name = zp_estimate_list[i],  zp_name_list[i]
        ax.scatter( zs[::10], zp[::10], s=1, label=zp_name )     
        ax.set(xlabel=r'$z_{\rm s}$', ylabel=r'$z_{\rm p}$') 

if __name__=='__main__':
"""
This program performs the training and testing of the cNSF pipeline
"""
    # read in the condition data and the redshift data (x)        
    condition_data, x_data = get_full_dataset()
    condition_data, x_data = shuffle(condition_data, x_data, random_state=42) # shuffle it , just to be sure

    # split into training, validation and test parts 
    x1_train, x2_train = train_validate_test_split( condition_data, x_data, 0 )
    x1_validate, x2_validate = train_validate_test_split( condition_data, x_data, 1 )
    x1_test, x2_test = train_validate_test_split( condition_data, x_data, 2 )

    mean = np.mean(x2_train)
    std = np.std(x2_train)
    print(mean)
    print(std)
    
    # preform scaling transformation to put the data on a similar scale 
    scaler_condition = StandardScaler()
    x1_train = scaler_condition.fit_transform(x1_train) 
    x1_validate = scaler_condition.transform(x1_validate)  
    x1_test = scaler_condition.transform(x1_test)

    scaler_x = StandardScaler()
    x2_train = scaler_x.fit_transform(x2_train.reshape(-1, 1))
    x2_validate = scaler_x.transform(x2_validate.reshape(-1, 1))
    x2_test = scaler_x.transform(x2_test.reshape(-1, 1))
    
    x1_train = torch.tensor(x1_train, dtype=torch.float32).to(device)
    x1_validate = torch.tensor(x1_validate, dtype=torch.float32).to(device)
    x1_test = torch.tensor(x1_test, dtype=torch.float32).to(device)

    x2_train = torch.tensor(x2_train, dtype=torch.float32).to(device)
    x2_validate = torch.tensor(x2_validate, dtype=torch.float32).to(device)
    x2_test = torch.tensor(x2_test, dtype=torch.float32).to(device)

    print("x1_train.shape:", x1_train.shape)
    print("x2_train.shape:", x2_train.shape)
    print("x1_validate.shape:", x1_validate.shape)
    print("x2_validate.shape:", x2_validate.shape)

    #training 
    dist_x2_given_x1 = model_training(x1_train, x2_train, x1_validate, x2_validate)


    # testing 
    #zs = scaler_x.inverse_transform(x2_test.reshape(-1, 1)).flatten()
    zs = scaler_x.inverse_transform(x2_test.detach().cpu().numpy().reshape(-1, 1)).flatten()

    z_maxp, z_median, z_mean, err_std, err_68halfpc, pit = test_sample_dist( x1_test, x2_test, zs, mean, std )
    #plot_pdf_for_one_source(x2_flow, zs, i=100)

    zp_estimate_list = [ z_maxp, z_median, z_mean ]
    zp_name_list = [ 'z_maxp', 'z_median', 'z_mean' ]

    for i in range(len(zp_estimate_list)):
        zp, zp_name = zp_estimate_list[i],  zp_name_list[i]
        
        outlier_fraction = get_outlier_frac(zp, zs, zp_name)
        sigma_nmad = get_sigma(zp, zs, zp_name)
        bias = get_bias(zp,zs,zp_name)

    make_scatter_plot( zp_estimate_list, zp_name_list )        

    print('\n')
    print('batch_size:', batch_size)
    #print('Type:',photometry_type, photoz_type )
    #print('magnitude:', mag_min,'-',mag_max)
    print('Epoch:', N_epochs)
    print('milestones:','[',change1,change2,']')
    print('Patience limit:', patience_limit)
    print('num_layers',num_layers)
    print('lr', lr)

    #for test only
    '''
    np.save("x1_test.npy", x1_test.cpu().numpy())
    np.save("x2_test.npy", x2_test.cpu().numpy())
    np.save("mean_std.npy", np.array([mean, std]))
    '''
    
    output_file = "DES/ZMAG_shape_impute/zp_zs_Nlayers%d_%d_%s.txt"   %(num_layers ,steps, file)
    output_list =  np.transpose([ zs, z_maxp, z_median, z_mean, err_std, err_68halfpc ])  

    outpit_file = "DES/ZMAG_shape_impute/cnsf_pit_%s.txt" %(file)
    outpit_list = np.transpose([ pit])   
    
    np.savetxt( output_file, output_list, fmt="  %.6f ", comments="")
 
    pl.show()
